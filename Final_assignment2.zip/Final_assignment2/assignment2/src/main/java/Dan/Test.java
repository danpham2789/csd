/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dan;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author Admin
 */
public class Test {
    public static void main(String[] args) {
        MaxHeap mHeap = new MaxHeap();
        String filePath = "books.tsv";
        String line;
        String splitBy = "\t";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String header = br.readLine();

            while ((line = br.readLine()) != null) {
                String[] data = line.split(splitBy);
                try {
                    Book b = new Book(data[0].strip(), data[1].strip(), data[2].strip(), Integer.parseInt(data[3].strip()), data[4].strip(), data[5].strip(), data[5].strip(), data[6].strip());
                    mHeap.insert(b);
                    //System.out.println(b);
                } catch (NumberFormatException err){
                    //System.out.println(err);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("First element (root): ");
        System.out.println(mHeap.arr[0].data);
        
        System.out.println("");
        System.out.println("Before delete first: ");
        System.out.println(mHeap.search("à¸£?à¸¢?thique en toc"));
        mHeap.deleteFirst();
        System.out.println("After delete first: ");
        System.out.println(mHeap.search("à¸£?à¸¢?thique en toc") == null ? "Not found" : mHeap.search("à¸£?à¸¢?thique en toc"));
    }
}
