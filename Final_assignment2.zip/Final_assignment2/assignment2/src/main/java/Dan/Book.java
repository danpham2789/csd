/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dan;

/**
 *
 * @author Admin
 */
public class Book {
    private String ISBN;
    private String bookTitle;
    private String author;
    private int yearOfPublic;
    private String publisher;
    private String imageUrlS;
    private String imageUrlM;
    private String imageUrlL;

    public Book(String ISBN, String bookTitle, String author, int yearOfPublic, String publisher, String imageUrlS, String imageUrlM, String imageUrlL) {
        this.ISBN = ISBN;
        this.bookTitle = bookTitle;
        this.author = author;
        this.yearOfPublic = yearOfPublic;
        this.publisher = publisher;
        this.imageUrlS = imageUrlS;
        this.imageUrlM = imageUrlM;
        this.imageUrlL = imageUrlL;
    }

    public Book() {
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getYearOfPublic() {
        return yearOfPublic;
    }

    public void setYearOfPublic(int yearOfPublic) {
        this.yearOfPublic = yearOfPublic;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getImageUrlS() {
        return imageUrlS;
    }

    public void setImageUrlS(String imageUrlS) {
        this.imageUrlS = imageUrlS;
    }

    public String getImageUrlM() {
        return imageUrlM;
    }

    public void setImageUrlM(String imageUrlM) {
        this.imageUrlM = imageUrlM;
    }

    public String getImageUrlL() {
        return imageUrlL;
    }

    public void setImageUrlL(String imageUrlL) {
        this.imageUrlL = imageUrlL;
    }

    @Override
    public String toString() {
        return "ISBN: " + ISBN + ", bookTitle: " + bookTitle + ", author: " + author + ", yearOfPublic: " + yearOfPublic + ", publisher: " + publisher + ", imageUrlS: " + imageUrlS + ", imageUrlM: " + imageUrlM + ", imageUrlL: " + imageUrlL;
    }
    
    
    
    
}
