/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dan;

/**
 *
 * @author Admin
 */
public class MaxHeap {
    public class Node{
        Book data;

        public Node(Book data) {
            this.data = data;
        }
    }
    
    Node[] arr;
    int capacity;
    int lastIdx;
    
    public MaxHeap(int capacity){
        this.lastIdx = -1;
        this.capacity = capacity;
        arr = new Node[capacity];
    }
    
    public MaxHeap(){
        this(10);
    }
    
    boolean isEmpty(){
        return lastIdx == -1;
    }
    
    boolean isFull(){
        return lastIdx == capacity - 1;
    }
    
    void increaseCap(){
        capacity = (int)(capacity*1.5);
        Node[] temp = new Node[capacity];
        for (int i = 0 ; i <= lastIdx; i++){
            temp[i] = arr[i];
        }
        arr = temp;
    }
    
    void heaptifyUp(int child){
        int parent = (child - 1)/2;
        while (arr[child].data.getBookTitle().compareTo(arr[parent].data.getBookTitle()) >  0 && child > 0){
            Book temp = arr[child].data;
            arr[child].data = arr[parent].data;
            arr[parent].data = temp;
            child = parent;
            parent = (child- 1)/2;
        }
    }
    
    void insert(Book x){
        if (isFull()) increaseCap();
        arr[++lastIdx] = new Node(x);
        heaptifyUp(lastIdx);
    }
    
    void heaptifyDown(int i){
        int largest = i;
        int left = largest * 2 + 1;
        int right = largest * 2 + 2;
        while(true){
            if (left <= lastIdx && arr[left].data.getBookTitle().compareTo(arr[largest].data.getBookTitle()) > 0) 
                largest = left;
            if (right <= lastIdx && arr[right].data.getBookTitle().compareTo(arr[largest].data.getBookTitle()) > 0) 
                largest = right;

            if (largest != i){
                Node temp = arr[largest];
                arr[largest] = arr[i];
                arr[i] = temp;
                i = largest;
                left = largest * 2 + 1;
                right = largest * 2 + 2;
            } else break;
        }
    }
    
    void delete(Book x){
        if (isEmpty()) {System.out.println("Empty heap"); return;}
        int foundIdx = -1;
        for (int i = 0; i <= lastIdx; i++){
            if (arr[i].data == x) {foundIdx = i; break;}
        }
        if (foundIdx != -1) {
            arr[foundIdx] = arr[lastIdx--];
            heaptifyDown(foundIdx);
        }
    }
    
    void deleteFirst(){
        if (isEmpty()) {System.out.println("Empty heap"); return;}
        delete(arr[0].data);
    }
    
    Book search(String name){
        for (int i = 0; i <= lastIdx; i++){
            if (arr[i].data.getBookTitle().equals(name)) {return arr[i].data;}
        }
        return null;
    }
    
    void preOrder(int index){
        if (index > lastIdx) return;
        System.out.println(arr[index].data + " ");
        preOrder(2 * index + 1); //visit left
        preOrder(2 * index + 2); //visit right
    }
    
    void preOrder(){
        if(isEmpty()) System.out.println("Empty");
        else {
            preOrder(0);
            System.out.println("");
        }
    }
    
    void postOrder(int index){
        if (index > lastIdx) return;
        postOrder(2 * index + 1);
        postOrder(2 * index + 2);
        System.out.println(arr[index].data + " ");
    }
    
    void postOrder(){
        if(isEmpty()) System.out.println("Empty");
        else {
            postOrder(0);
            System.out.println("");
        }
    }
    
    void inOrder(int index){
        if (index > lastIdx) return;
        inOrder(2 * index + 1);
        System.out.println(arr[index].data);
        inOrder(2 * index + 2);
    }
    
    void inOrder(){
        if(isEmpty()) System.out.println("Empty");
        else {
            inOrder(0);
            System.out.println("");
        }
    }
    
    void travarse(){
        System.out.println("Pre order: ");
        preOrder();
        System.out.printf("In order: \n");
        inOrder();
        System.out.println("Post order: ");
        postOrder();
    }
    
}
