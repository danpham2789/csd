/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Duong;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author ADMIN
 */
public class Test {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AVLTree tree = new AVLTree();
        Node root = null;
        try (BufferedReader br = new BufferedReader(new FileReader("books.tsv"))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split("\t");
                if (data.length >= 8) {
                    String isbn = data[0]; 
                    String bookName = data[1];
                    String bookInfo = data[1] + " | " + data[2] + " | " + data[3] + " | " + data[4] + " | " + data[5] + " | " + data[6] + " | " + data[7];
                    root = tree.insert(root, isbn, bookName, bookInfo);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        //System.out.println("All books:");
        //tree.printInOrder(root);

        System.out.print("Enter ISBN to search: ");
        String searchKey = scanner.nextLine();
        tree.search(root, searchKey);

        root = tree.deleteFirst(root);
        System.out.println("Deleted first book.");
         System.out.println("All books:");
         tree.printInOrder(root);
    }
}
