/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Duong;

/**
 *
 * @author ADMIN
 */
public class AVLTree {
     private int height(Node node) {
        return node == null ? 0 : node.height;
    }

    private int getBalance(Node node) {
        return node == null ? 0 : height(node.left) - height(node.right);
    }

    private Node rotateRight(Node y) {
        Node x = y.left;
        Node T2 = x.right;
        x.right = y;
        y.left = T2;
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        return x;
    }

    private Node rotateLeft(Node x) {
        Node y = x.right;
        Node T2 = y.left;
        y.left = x;
        x.right = T2;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        return y;
    }

    public Node insert(Node node, String key, String bookName, String value) {
        if (node == null) return new Node(key, bookName, value);
        if (key.compareTo(node.key) < 0)
            node.left = insert(node.left, key, bookName, value);
        else
            node.right = insert(node.right, key, bookName, value);
        node.height = Math.max(height(node.left), height(node.right)) + 1;
        return rebalance(node);
    }

    private Node rebalance(Node node) {
        int balance = getBalance(node);
        if (balance > 1) {
            if (getBalance(node.left) < 0)
                node.left = rotateLeft(node.left);
            return rotateRight(node);
        }
        if (balance < -1) {
            if (getBalance(node.right) > 0)
                node.right = rotateRight(node.right);
            return rotateLeft(node);
        }
        return node;
    }

    public Node search(Node node, String key) {
        if (node == null || node.key.equalsIgnoreCase(key)) {
            if (node != null) {
                System.out.println("Found: " + node.value);
            } else {
                System.out.println("Not found");
            }
            return node;
        }
        return key.compareToIgnoreCase(node.key) < 0 ? search(node.left, key) : search(node.right, key);
    }

    public Node deleteFirst(Node root) {
        if (root == null) return null;
        if (root.left == null) return root.right;
        Node parent = null, current = root;
        while (current.left != null) {
            parent = current;
            current = current.left;
        }
        if (parent != null) {
            parent.left = current.right;
        }
        return rebalance(root);
    }

    private Node minValueNode(Node node) {
        Node current = node;
        while (current.left != null)
            current = current.left;
        return current;
    }
    public void printInOrder(Node node) {
    if (node != null) {
        printInOrder(node.left);
        System.out.println(node.key + " -> " + node.value);
        printInOrder(node.right);
    }
}
}
