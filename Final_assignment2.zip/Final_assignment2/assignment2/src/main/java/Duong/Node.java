/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Duong;

/**
 *
 * @author ADMIN
 */
public class Node {
    String key; 
    String bookName;
    String value;
    int height;
    Node left, right;


    public Node(String key, String bookName, String value) {
        this.key = key;
        this.bookName = bookName;
        this.value = value;
        this.height = 1;
    }
}


