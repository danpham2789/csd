package Thinh;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class BSTBook {

    class Node {

        String isbn, bookTitle, bookAuthor, year, publisher, imgS, imgM, imgL;
        Node left, right;

        public Node(String isbn, String bookTitle, String bookAuthor, String year, String publisher, String imgS, String imgM, String imgL) {
            this.isbn = isbn;
            this.bookTitle = bookTitle;
            this.bookAuthor = bookAuthor;
            this.year = year;
            this.publisher = publisher;
            this.imgS = imgS;
            this.imgM = imgM;
            this.imgL = imgL;
            this.left = this.right = null;
        }
    }

    private Node root;

    public BSTBook() {
        this.root = null;
    }

    boolean isEmpty() {
        return root == null;
    }

    void insert(String isbn, String bookTitle, String bookAuthor, String year, String publisher, String imgS, String imgM, String imgL) {
        root = insertRec(root, isbn, bookTitle, bookAuthor, year, publisher, imgS, imgM, imgL);
    }

    private Node insertRec(Node node, String isbn, String bookTitle, String bookAuthor, String year, String publisher, String imgS, String imgM, String imgL) {
        if (node == null) {
            return new Node(isbn, bookTitle, bookAuthor, year, publisher, imgS, imgM, imgL);
        }
        if (isbn.compareTo(node.isbn) < 0) {
            node.left = insertRec(node.left, isbn, bookTitle, bookAuthor, year, publisher, imgS, imgM, imgL);
        } else if (isbn.compareTo(node.isbn) > 0) {
            node.right = insertRec(node.right, isbn, bookTitle, bookAuthor, year, publisher, imgS, imgM, imgL);
        }
        return node;
    }

    void loadFromTSV(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(new File(filePath)))) {
            String line;
            boolean firstLine = true;
            while ((line = br.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue;
                }

                String[] columns = line.split("\t");
                if (columns.length >= 8) {
                    insert(columns[0].trim(), columns[1].trim(), columns[2].trim(), columns[3].trim(),
                            columns[4].trim(), columns[5].trim(), columns[6].trim(), columns[7].trim());
                }
            }
            System.out.println("Add success data");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Node searchByISBN(String isbn) {
        System.out.println("Searching for ISBN: " + isbn);
        return searchByISBNRec(root, isbn);
    }

    private Node searchByISBNRec(Node node, String isbn) {
        if (node == null || node.isbn.equalsIgnoreCase(isbn)) {
            return node;
        }
        if (isbn.compareTo(node.isbn) < 0) {
            return searchByISBNRec(node.left, isbn);
        }
        return searchByISBNRec(node.right, isbn);
    }

    public void deleteByISBN(String isbn) {
        root = deleteByISBNRec(root, isbn);
    }

    private Node deleteByISBNRec(Node node, String isbn) {
        if (node == null) {
            return null;
        }

        if (isbn.compareTo(node.isbn) < 0) {
            node.left = deleteByISBNRec(node.left, isbn);
        } else if (isbn.compareTo(node.isbn) > 0) {
            node.right = deleteByISBNRec(node.right, isbn);
        } else {

            if (node.left == null) {
                return node.right;
            }
            if (node.right == null) {
                return node.left;
            }

            Node minNode = findMin(node.right);
            node.isbn = minNode.isbn;
            node.bookTitle = minNode.bookTitle;
            node.bookAuthor = minNode.bookAuthor;
            node.year = minNode.year;
            node.publisher = minNode.publisher;
            node.imgS = minNode.imgS;
            node.imgM = minNode.imgM;
            node.imgL = minNode.imgL;

            node.right = deleteByISBNRec(node.right, minNode.isbn);
        }
        return node;
    }

    private Node findMin(Node node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

    void inOrder(Node node) {
        if (node == null) {
            return;
        }
        inOrder(node.left);
        System.out.println("ISBN: " + node.isbn + " | Title: " + node.bookTitle + " | Author: " + node.bookAuthor
                + " | Year: " + node.year + " | Publisher: " + node.publisher
                + " | Image-S: " + node.imgS + " | Image-M: " + node.imgM + " | Image-L: " + node.imgL);
        inOrder(node.right);
    }

    void inOrder() {
        if (isEmpty()) {
            System.out.println("empty");
        } else {
            inOrder(root);
        }
    }
}
