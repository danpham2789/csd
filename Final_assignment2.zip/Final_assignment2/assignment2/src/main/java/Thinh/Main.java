package Thinh;

import java.util.Scanner;
import java.io.File;

public class Main {
    public static void main(String[] args) {
        BSTBook bst = new BSTBook();
        Scanner scanner = new Scanner(System.in);
        String filePath = "src/book.tsv";

        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("Error: File not found - " + filePath);
            return;
        }
        bst.loadFromTSV(filePath);
        System.out.println("\nBook list successfully loaded:");
        bst.inOrder();

        while (true) {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Search for a book");
            System.out.println("2. Delete a book");
            System.out.println("3. Display book list");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number!");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.print("Enter ISBN to search: ");
                    String searchISBN = scanner.nextLine().trim();
                    BSTBook.Node found = bst.searchByISBN(searchISBN);
                    if (found != null) {
                        System.out.println("Book found:");
                        System.out.println("Title: " + found.bookTitle);
                        System.out.println("Author: " + found.bookAuthor);
                        System.out.println("Year: " + found.year);
                        System.out.println("Publisher: " + found.publisher);
                    } else {
                        System.out.println("No book found with ISBN: " + searchISBN);
                    }
                    break;

                case 2:
                    System.out.print("Enter ISBN to delete: ");
                    String deleteISBN = scanner.nextLine().trim();
                    bst.deleteByISBN(deleteISBN);
                    System.out.println("Book with ISBN " + deleteISBN + " has been deleted.");
                    break;

                case 3:
                    System.out.println("\nBook list:");
                    bst.inOrder();
                    break;

                case 4:
                    System.out.println("Exiting program.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Please choose a number between 1-4.");
            }
        }
    }
}

/*
Đối với BST thì thời gian lưu trữ dữ liệu là O(log N) và nó chặm hơn so với arraylist, thời gian tìm kiếm thì ngược lại nhanh hơn so với arraylist

nếu trong BST với cây mất cân bằng thì sẽ là O(n) 
*/